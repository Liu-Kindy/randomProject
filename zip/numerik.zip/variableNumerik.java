public class variableNumerik {
    public static void main(String[] args) {
    int berat=56;
    int tinggi=160;
    int uangDompet=30000;
    int uangRekening=2100000000;
    long nilaiInvestasi=30000000000L;
    double jarak=5.5;
    System.out.println("Berat Badan: "+berat+"Kg");
    System.out.println("Tinggi: "+tinggi+"cm");
    System.out.printf("Uang di Dompet: Rp %,d%n", uangDompet);
    System.out.printf("Uang di Rekening: Rp %,d%n", uangRekening);
    System.out.printf("Nilai Investasi: Rp %,d%n", nilaiInvestasi);
    System.out.println("Jarak Sekolah: "+jarak+"km");
    
    }
}
