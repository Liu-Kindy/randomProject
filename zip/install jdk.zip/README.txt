Saya sudah menginstallnya sebelum masuk kelas industri dan tidak ingin me re-install nya 
sudah di ajarkan oleh pak dendi di awal masuk kelas pplg/rpl


-Uno fathir ar royyan kindy